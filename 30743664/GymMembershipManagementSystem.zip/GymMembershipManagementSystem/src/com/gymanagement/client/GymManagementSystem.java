package com.gymanagement.client;

import com.gymanagement.implementation.MemberDAOImpl;
import com.gymanagement.implementation.TrainerDAOImpl;
import com.gymanagement.implementation.MembershipPlanDAOImpl;
import com.gymanagement.model.Member;
import com.gymanagement.model.Trainer;
import com.gymanagement.model.MembershipPlan;

import java.util.List;
import java.util.Scanner;

public class GymManagementSystem {
    private static final MemberDAOImpl memberDAO = new MemberDAOImpl();
    private static final TrainerDAOImpl trainerDAO = new TrainerDAOImpl();
    private static final MembershipPlanDAOImpl planDAO = new MembershipPlanDAOImpl();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("Gym Membership Management System");
            System.out.println("1. Manage Members");
            System.out.println("2. Manage Trainers");
            System.out.println("3. Manage Membership Plans");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    manageMembers();
                    break;
                case 2:
                    manageTrainers();
                    break;
                case 3:
                    managePlans();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageMembers() {
        System.out.println("Member Management");
        System.out.println("1. Add Member");
        System.out.println("2. View Member Details");
        System.out.println("3. Update Member Information");
        System.out.println("4. Delete Member");
        System.out.println("5. View All Members");
        System.out.println("6. Back to Main Menu");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addMember();
                break;
            case 2:
                viewMember();
                break;
            case 3:
                updateMember();
                break;
            case 4:
                deleteMember();
                break;
            case 5:
                viewAllMembers();
                break;
            case 6:
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void manageTrainers() {
        System.out.println("Trainer Management");
        System.out.println("1. Add Trainer");
        System.out.println("2. View Trainer Details");
        System.out.println("3. Update Trainer Information");
        System.out.println("4. Delete Trainer");
        System.out.println("5. View All Trainers");
        System.out.println("6. Back to Main Menu");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addTrainer();
                break;
            case 2:
                viewTrainer();
                break;
            case 3:
                updateTrainer();
                break;
            case 4:
                deleteTrainer();
                break;
            case 5:
                viewAllTrainers();
                break;
            case 6:
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void managePlans() {
        System.out.println("Membership Plan Management");
        System.out.println("1. Create Plan");
        System.out.println("2. View Plan Details");
        System.out.println("3. Update Plan Information");
        System.out.println("4. Delete Plan");
        System.out.println("5. View All Plans");
        System.out.println("6. Back to Main Menu");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                createPlan();
                break;
            case 2:
                viewPlan();
                break;
            case 3:
                updatePlan();
                break;
            case 4:
                deletePlan();
                break;
            case 5:
                viewAllPlans();
                break;
            case 6:
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void addMember() {
        System.out.println("Adding New Member");
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Phone Number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter Address: ");
        String address = scanner.nextLine();

        Member member = new Member();
        member.setName(name);
        member.setEmail(email);
        member.setPhoneNumber(phoneNumber);
        member.setAddress(address);

        memberDAO.addMember(member);
        System.out.println("Member added successfully!");
    }

    private static void viewMember() {
        System.out.print("Enter Member ID: ");
        int memberId = scanner.nextInt();
        Member member = memberDAO.getMemberById(memberId);
        if (member != null) {
            System.out.println("Member ID: " + member.getMemberId());
            System.out.println("Name: " + member.getName());
            System.out.println("Email: " + member.getEmail());
            System.out.println("Phone Number: " + member.getPhoneNumber());
            System.out.println("Address: " + member.getAddress());
        } else {
            System.out.println("Member not found!");
        }
    }

    private static void updateMember() {
        System.out.print("Enter Member ID to update: ");
        int memberId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        Member member = memberDAO.getMemberById(memberId);
        if (member != null) {
            System.out.print("Enter new Name (current: " + member.getName() + "): ");
            String name = scanner.nextLine();
            System.out.print("Enter new Email (current: " + member.getEmail() + "): ");
            String email = scanner.nextLine();
            System.out.print("Enter new Phone Number (current: " + member.getPhoneNumber() + "): ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter new Address (current: " + member.getAddress() + "): ");
            String address = scanner.nextLine();

            member.setName(name);
            member.setEmail(email);
            member.setPhoneNumber(phoneNumber);
            member.setAddress(address);

            memberDAO.updateMember(member);
            System.out.println("Member information updated successfully!");
        } else {
            System.out.println("Member not found!");
        }
    }

    private static void deleteMember() {
        System.out.print("Enter Member ID to delete: ");
        int memberId = scanner.nextInt();
        memberDAO.deleteMember(memberId);
        System.out.println("Member deleted successfully!");
    }

    private static void viewAllMembers() {
        List<Member> members = memberDAO.getAllMembers();
        System.out.println("All Members:");
        for (Member member : members) {
            System.out.println("Member ID: " + member.getMemberId() + ", Name: " + member.getName());
        }
    }

    private static void addTrainer() {
        System.out.println("Adding New Trainer");
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Phone Number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter Speciality: ");
        String speciality = scanner.nextLine();

        Trainer trainer = new Trainer();
        trainer.setName(name);
        trainer.setEmail(email);
        trainer.setPhoneNumber(phoneNumber);
        trainer.setSpeciality(speciality);

        trainerDAO.addTrainer(trainer);
        System.out.println("Trainer added successfully!");
    }

    private static void viewTrainer() {
        System.out.print("Enter Trainer ID: ");
        int trainerId = scanner.nextInt();
        Trainer trainer = trainerDAO.getTrainerById(trainerId);
        if (trainer != null) {
            System.out.println("Trainer ID: " + trainer.getTrainerId());
            System.out.println("Name: " + trainer.getName());
            System.out.println("Email: " + trainer.getEmail());
            System.out.println("Phone Number: " + trainer.getPhoneNumber());
            System.out.println("Speciality: " + trainer.getSpeciality());
        } else {
            System.out.println("Trainer not found!");
        }
    }

    private static void updateTrainer() {
        System.out.print("Enter Trainer ID to update: ");
        int trainerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        Trainer trainer = trainerDAO.getTrainerById(trainerId);
        if (trainer != null) {
            System.out.print("Enter new Name (current: " + trainer.getName() + "): ");
            String name = scanner.nextLine();
            System.out.print("Enter new Email (current: " + trainer.getEmail() + "): ");
            String email = scanner.nextLine();
            System.out.print("Enter new Phone Number (current: " + trainer.getPhoneNumber() + "): ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter new Speciality (current: " + trainer.getSpeciality() + "): ");
            String speciality = scanner.nextLine();

            trainer.setName(name);
            trainer.setEmail(email);
            trainer.setPhoneNumber(phoneNumber);
            trainer.setSpeciality(speciality);

            trainerDAO.updateTrainer(trainer);
            System.out.println("Trainer information updated successfully!");
        } else {
            System.out.println("Trainer not found!");
        }
    }

    private static void deleteTrainer() {
        System.out.print("Enter Trainer ID to delete: ");
        int trainerId = scanner.nextInt();
        trainerDAO.deleteTrainer(trainerId);
        System.out.println("Trainer deleted successfully!");
    }

    private static void viewAllTrainers() {
        List<Trainer> trainers = trainerDAO.getAllTrainers();
        System.out.println("All Trainers:");
        for (Trainer trainer : trainers) {
            System.out.println("Trainer ID: " + trainer.getTrainerId() + ", Name: " + trainer.getName());
        }
    }

    private static void createPlan() {
        System.out.println("Creating New Membership Plan");
        System.out.print("Enter Plan Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Duration in Months: ");
        int durationMonths = scanner.nextInt();
        System.out.print("Enter Price per Month: ");
        double pricePerMonth = scanner.nextDouble();

        MembershipPlan plan = new MembershipPlan();
        plan.setName(name);
        plan.setDurationMonths(durationMonths);
        plan.setPricePerMonth(pricePerMonth);

        planDAO.createPlan(plan);
        System.out.println("Membership plan created successfully!");
    }

    private static void viewPlan() {
        System.out.print("Enter Plan ID: ");
        int planId = scanner.nextInt();
        MembershipPlan plan = planDAO.getPlanById(planId);
        if (plan != null) {
            System.out.println("Plan ID: " + plan.getPlanId());
            System.out.println("Name: " + plan.getName());
            System.out.println("Duration: " + plan.getDurationMonths() + " months");
            System.out.println("Price per Month: $" + plan.getPricePerMonth());
        } else {
            System.out.println("Plan not found!");
        }
    }

    private static void updatePlan() {
        System.out.print("Enter Plan ID to update: ");
        int planId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        MembershipPlan plan = planDAO.getPlanById(planId);
        if (plan != null) {
            System.out.print("Enter new Name (current: " + plan.getName() + "): ");
            String name = scanner.nextLine();
            System.out.print("Enter new Duration in Months (current: " + plan.getDurationMonths() + "): ");
            int durationMonths = scanner.nextInt();
            System.out.print("Enter new Price per Month (current: $" + plan.getPricePerMonth() + "): ");
            double pricePerMonth = scanner.nextDouble();

            plan.setName(name);
            plan.setDurationMonths(durationMonths);
            plan.setPricePerMonth(pricePerMonth);

            planDAO.updatePlan(plan);
            System.out.println("Membership plan updated successfully!");
        } else {
            System.out.println("Plan not found!");
        }
    }

    private static void deletePlan() {
        System.out.print("Enter Plan ID to delete: ");
        int planId = scanner.nextInt();
        planDAO.deletePlan(planId);
        System.out.println("Membership plan deleted successfully!");
    }

    private static void viewAllPlans() {
        List<MembershipPlan> plans = planDAO.getAllPlans();
        System.out.println("All Membership Plans:");
        for (MembershipPlan plan : plans) {
            System.out.println("Plan ID: " + plan.getPlanId() + ", Name: " + plan.getName());
        }
    }
}
