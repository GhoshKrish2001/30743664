package com.gymanagement.dao;

import com.gymanagement.model.Member;
import java.util.List;

public interface MemberDAO {
    void addMember(Member member);
    Member getMemberById(int memberId);
    List<Member> getAllMembers();
    void updateMember(Member member);
    void deleteMember(int memberId);
}
