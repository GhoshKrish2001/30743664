package com.gymanagement.dao;

import com.gymanagement.model.MembershipPlan;
import java.util.List;

public interface MembershipPlanDAO {
    void createPlan(MembershipPlan plan);
    MembershipPlan getPlanById(int planId);
    List<MembershipPlan> getAllPlans();
    void updatePlan(MembershipPlan plan);
    void deletePlan(int planId);
}
