package com.gymanagement.implementation;

import com.gymanagement.dao.MembershipPlanDAO;
import com.gymanagement.model.MembershipPlan;
import com.gymanagement.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MembershipPlanDAOImpl implements MembershipPlanDAO {

    @Override
    public void createPlan(MembershipPlan plan) {
        String query = "INSERT INTO MembershipPlan(name, duration_months, price_per_month) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, plan.getName());
            statement.setInt(2, plan.getDurationMonths());
            statement.setDouble(3, plan.getPricePerMonth());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public MembershipPlan getPlanById(int planId) {
        String query = "SELECT * FROM MembershipPlan WHERE plan_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, planId);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                MembershipPlan plan = new MembershipPlan();
                plan.setPlanId(rs.getInt("plan_id"));
                plan.setName(rs.getString("name"));
                plan.setDurationMonths(rs.getInt("duration_months"));
                plan.setPricePerMonth(rs.getDouble("price_per_month"));
                return plan;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<MembershipPlan> getAllPlans() {
        List<MembershipPlan> plans = new ArrayList<>();
        String query = "SELECT * FROM MembershipPlan";
        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {
            while (rs.next()) {
                MembershipPlan plan = new MembershipPlan();
                plan.setPlanId(rs.getInt("plan_id"));
                plan.setName(rs.getString("name"));
                plan.setDurationMonths(rs.getInt("duration_months"));
                plan.setPricePerMonth(rs.getDouble("price_per_month"));
                plans.add(plan);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return plans;
    }

    @Override
    public void updatePlan(MembershipPlan plan) {
        String query = "UPDATE MembershipPlan SET name = ?, duration_months = ?, price_per_month = ? WHERE plan_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, plan.getName());
            statement.setInt(2, plan.getDurationMonths());
            statement.setDouble(3, plan.getPricePerMonth());
            statement.setInt(4, plan.getPlanId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deletePlan(int planId) {
        String query = "DELETE FROM MembershipPlan WHERE plan_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, planId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
