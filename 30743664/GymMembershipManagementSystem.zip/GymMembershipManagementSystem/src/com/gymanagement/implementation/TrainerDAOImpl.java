package com.gymanagement.implementation;

import com.gymanagement.dao.TrainerDAO;
import com.gymanagement.model.Trainer;
import com.gymanagement.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TrainerDAOImpl implements TrainerDAO {

    @Override
    public void addTrainer(Trainer trainer) {
        String query = "INSERT INTO Trainer(name, email, phone_number, speciality) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, trainer.getName());
            statement.setString(2, trainer.getEmail());
            statement.setString(3, trainer.getPhoneNumber());
            statement.setString(4, trainer.getSpeciality());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Trainer getTrainerById(int trainerId) {
        String query = "SELECT * FROM Trainer WHERE trainer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, trainerId);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                Trainer trainer = new Trainer();
                trainer.setTrainerId(rs.getInt("trainer_id"));
                trainer.setName(rs.getString("name"));
                trainer.setEmail(rs.getString("email"));
                trainer.setPhoneNumber(rs.getString("phone_number"));
                trainer.setSpeciality(rs.getString("speciality"));
                return trainer;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Trainer> getAllTrainers() {
        List<Trainer> trainers = new ArrayList<>();
        String query = "SELECT * FROM Trainer";
        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {
            while (rs.next()) {
                Trainer trainer = new Trainer();
                trainer.setTrainerId(rs.getInt("trainer_id"));
                trainer.setName(rs.getString("name"));
                trainer.setEmail(rs.getString("email"));
                trainer.setPhoneNumber(rs.getString("phone_number"));
                trainer.setSpeciality(rs.getString("speciality"));
                trainers.add(trainer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return trainers;
    }

    @Override
    public void updateTrainer(Trainer trainer) {
        String query = "UPDATE Trainer SET name = ?, email = ?, phone_number = ?, speciality = ? WHERE trainer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, trainer.getName());
            statement.setString(2, trainer.getEmail());
            statement.setString(3, trainer.getPhoneNumber());
            statement.setString(4, trainer.getSpeciality());
            statement.setInt(5, trainer.getTrainerId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteTrainer(int trainerId) {
        String query = "DELETE FROM Trainer WHERE trainer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, trainerId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
